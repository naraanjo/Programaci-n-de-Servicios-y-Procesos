/**
 * 
 */
/**
 * 
 */
module simulacro {
}